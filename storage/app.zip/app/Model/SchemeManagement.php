<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SchemeManagement extends Model
{
    protected $table = 'scheme_managements';

}
