<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ProviderWalletHistory extends Model
{
    //
}
