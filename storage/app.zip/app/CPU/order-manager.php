<?php

namespace App\CPU;

use App\Model\Admin;
use App\Model\AdminWallet;
use App\Model\CustomerWalletHistory;
use App\Model\Cart;
use App\Model\CartShipping;
use App\Model\Coupon;
use App\Model\Order;
use App\Model\OrderDetail;
use App\Model\OrderTransaction;
use App\Model\Product;
use App\Model\Seller;
use App\Model\SellerWallet;
use App\Model\WalletTransaction;
use App\Model\ShippingType;
use App\Model\ShippingAddress;
use App\Model\Transaction;
use App\Traits\CommonTrait;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\User;


class OrderManager
{
    use CommonTrait;
    public static function track_order($order_id)
    {
       
       
        $order = Order::with(['delivery_man', 'order_status_history'=>function($query){
            return $query->latest();
        }, 'shiprocket_courier'])->where(['id' => $order_id])->first();

       // dd($order);
        
        $order['billing_address_data'] = json_decode($order['billing_address_data']);
        $order['shipping_address_data'] = json_decode($order['shipping_address_data']);
       
         $address = [
                "pickup_location" => str_replace(" ", "", $order->seller->shop->name),
            	"name" => $order->seller->shop->name,
            	"email" => $order->seller->email,
            	"phone" => str_starts_with($order->seller->phone, "91") ? substr($order->seller->phone, 2, 10) : $order->seller->phone,
            	"address" => $order->seller->shop->address,
            	"address_2" => "",
            	"city" => $order->seller->shop->city,
            	"state" => $order->seller->shop->state,
            	"country" => $order->seller->shop->country,
            	"pin_code" => $order->seller->shop->pincode
            ];
            
             $order['pickup_address_data'] = $address;

            
        
        return $order;
    }

    public static function gen_unique_id()
    {
        return rand(1000, 9999) . '-' . Str::random(5) . '-' . time();
    }

    public static function order_summary($order)
    {
        $sub_total = 0;
        $total_tax = 0;
        $total_discount_on_product = 0;
        foreach ($order->details as $key => $detail) {
            $sub_total += $detail->price * $detail->qty;
            $total_tax += $detail->tax;
            $total_discount_on_product += $detail->discount;
        }
        $total_shipping_cost = $order['shipping_cost'];
        return [
            'subtotal' => $sub_total,
            'total_tax' => $total_tax,
            'total_discount_on_product' => $total_discount_on_product,
            'total_shipping_cost' => $total_shipping_cost,
        ];
    }

    public static function order_summary_before_place_order($cart, $coupon_discount)
    {
        $coupon_code = session()->has('coupon_code') ? session('coupon_code') : 0;
        $coupon = Coupon::where(['code' => $coupon_code])
            ->where('status',1)
            ->first();

        $sub_total = 0;
        $total_discount_on_product = 0;

        if($coupon && ($coupon->seller_id == NULL || $coupon->seller_id == '0' || $coupon->seller_id == $cart[0]->seller_id)){
            $coupon_discount = $coupon->coupon_type == 'free_delivery' ? 0 : $coupon_discount;
        }else{
            $coupon_discount = 0;
        }
          //dd($cart);
        foreach ($cart as $item) {
            $price = DB::table('sku_product_new')->where('id',$item->variation)->first();
            $sub_total += $price->listed_price * $item->quantity;
          //  $total_discount_on_product += $price->discount * $item->quantity;
        }

        $order_total = $sub_total-$coupon_discount;
       // dd($order_total);
        return [
            'order_total' => $order_total
        ];
    }


    public static function stock_update_on_order_status_changes($order_detail, $status){
        
         if ($status == 'returned' || $status == 'failed' || $status == 'canceled') {
            //dd($order_detail->product_id,$order_detail->variant,$order_detail->qty);
              $quanti = DB::table('sku_product_new')
                   ->where('product_id',$order_detail->product_id)
                   ->where('variation',$order_detail->variant)
                    ->increment('quantity', $order_detail->qty);
                   //dd($quanti);

                  
         }
        
         return response()->json('successfully update quantity');
    }

    public static function stock_update_on_order_status_change($order, $status)
    {
        if ($status == 'returned' || $status == 'failed' || $status == 'canceled') {
            foreach ($order->details as $detail) {
                if ($detail['is_stock_decreased'] == 1) {
                    $product = Product::find($detail['product_id']);
                    $type = $detail['variant'];
                    $var_store = [];
                    foreach (json_decode($product['variation'], true) as $var) {
                        if ($type == $var['type']) {
                            $var['qty'] += $detail['qty'];
                        }
                        array_push($var_store, $var);
                    }
                    Product::where(['id' => $product['id']])->update([
                        'variation' => json_encode($var_store),
                        'current_stock' => $product['current_stock'] + $detail['qty'],
                    ]);
                    OrderDetail::where(['id' => $detail['id']])->update([
                        'is_stock_decreased' => 0,
                        'delivery_status' => $status
                    ]);
                }
            }
        } else {
            foreach ($order->details as $detail) {
                if ($detail['is_stock_decreased'] == 0) {
                    $product = Product::find($detail['product_id']);

                    $type = $detail['variant'];
                    $var_store = [];
                    foreach (json_decode($product['variation'], true) as $var) {
                        if ($type == $var['type']) {
                            $var['qty'] -= $detail['qty'];
                        }
                        array_push($var_store, $var);
                    }
                    Product::where(['id' => $product['id']])->update([
                        'variation' => json_encode($var_store),
                        'current_stock' => $product['current_stock'] - $detail['qty'],
                    ]);
                    OrderDetail::where(['id' => $detail['id']])->update([
                        'is_stock_decreased' => 1,
                        'delivery_status' => $status
                    ]);
                }
            }
        }
    }

    public static function wallet_manage_on_order_status_change($order, $received_by)
    {
        $order = Order::find($order['id']);
        $order_summary = OrderManager::order_summary($order);
        $order_amount = $order_summary['subtotal'] - $order_summary['total_discount_on_product'] - $order['discount_amount'];
        $commission = $order['admin_commission'];
        $shipping_model = Helpers::get_business_settings('shipping_method');

        if (AdminWallet::where('admin_id', 1)->first() == false) {
            DB::table('admin_wallets')->insert([
                'admin_id' => 1,
                'withdrawn' => 0,
                'commission_earned' => 0,
                'inhouse_earning' => 0,
                'delivery_charge_earned' => 0,
                'pending_amount' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
        if (SellerWallet::where('seller_id', $order['seller_id'])->first() == false) {
            DB::table('seller_wallets')->insert([
                'seller_id' => $order['seller_id'],
                'withdrawn' => 0,
                'commission_given' => 0,
                'total_earning' => 0,
                'pending_withdraw' => 0,
                'delivery_charge_earned' => 0,
                'collected_cash' => 0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        if($order->coupon_code && $order->coupon_code != '0' && $order->seller_is == 'seller' && $order->discount_type == 'coupon_discount'){
            if($order->coupon_discount_bearer == 'inhouse'){
                $seller_wallet = SellerWallet::where('seller_id',$order->seller_id)->first();
                $seller_wallet->total_earning += $order->discount_amount;
                $seller_wallet->save();

                $paid_by = 'admin';
                $payer_id = 1;
                $payment_receiver_id = $order->seller_id;
                $paid_to = 'seller';

            }elseif($order->coupon_discount_bearer == 'seller'){
                $paid_by = 'seller';
                $payer_id = $order->seller_id;
                $payment_receiver_id = $order->seller_id;
                $paid_to = 'admin';
            }

            $transaction = new Transaction();
            $transaction->order_id = $order->id;
            $transaction->payment_for = 'coupon_discount';
            $transaction->payer_id = $payer_id;
            $transaction->payment_receiver_id = $payment_receiver_id;
            $transaction->paid_by = $paid_by;
            $transaction->paid_to = $paid_to;
            $transaction->payment_status = 'disburse';
            $transaction->amount = $order->discount_amount;
            $transaction->transaction_type = 'expense';
            $transaction->save();
        }

        if ($order['payment_method'] == 'cash_on_delivery' || $order['payment_method'] == 'offline_payment') {
            DB::table('order_transactions')->insert([
                'transaction_id' => OrderManager::gen_unique_id(),
                'customer_id' => $order['customer_id'],
                'seller_id' => $order['seller_id'],
                'seller_is' => $order['seller_is'],
                'order_id' => $order['id'],
                'order_amount' => $order_amount,
                'seller_amount' => $order_amount - $commission,
                'admin_commission' => $commission,
                'received_by' => $received_by,
                'status' => 'disburse',
                'delivery_charge' => $order['shipping_cost'],
                'tax' => $order_summary['total_tax'],
                'delivered_by' => $received_by,
                'payment_method' => $order['payment_method'],
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $wallet = AdminWallet::where('admin_id', 1)->first();
            $wallet->commission_earned += $commission;
            if ($shipping_model == 'inhouse_shipping') {
                $wallet->delivery_charge_earned += $order['shipping_cost'];
            }
            $wallet->save();

            if ($order['seller_is'] == 'admin') {
                $wallet = AdminWallet::where('admin_id', 1)->first();
                $wallet->inhouse_earning += $order_amount;
                if ($shipping_model == 'sellerwise_shipping') {
                    $wallet->delivery_charge_earned += $order['shipping_cost'];
                }
                $wallet->total_tax_collected += $order_summary['total_tax'];
                $wallet->save();
            } else {
                $wallet = SellerWallet::where('seller_id', $order['seller_id'])->first();
                $wallet->commission_given += $commission;
                $wallet->total_tax_collected += $order_summary['total_tax'];

                if ($shipping_model == 'sellerwise_shipping') {
                    $wallet->delivery_charge_earned += $order['shipping_cost'];
                    $wallet->collected_cash += $order['order_amount']; //total order amount
                } else {
                    $wallet->total_earning += ($order_amount - $commission) + $order_summary['total_tax'];
                }

                $wallet->save();
            }
        } else {
            $transaction = OrderTransaction::where(['order_id' => $order['id']])->first();
            $transaction->status = 'disburse';
            $transaction->save();

            $wallet = AdminWallet::where('admin_id', 1)->first();
            $wallet->commission_earned += $commission;
            $wallet->pending_amount -= $order['order_amount'];
            if ($shipping_model == 'inhouse_shipping') {
                $wallet->delivery_charge_earned += $order['shipping_cost'];
            }
            $wallet->save();

            if ($order['seller_is'] == 'admin') {
                $wallet = AdminWallet::where('admin_id', 1)->first();
                $wallet->inhouse_earning += $order_amount;
                if ($shipping_model == 'sellerwise_shipping') {
                    $wallet->delivery_charge_earned += $order['shipping_cost'];
                }
                $wallet->total_tax_collected += $order_summary['total_tax'];
                $wallet->save();
            } else {
                $wallet = SellerWallet::where('seller_id', $order['seller_id'])->first();
                $wallet->commission_given += $commission;

                if ($shipping_model == 'sellerwise_shipping') {
                    $wallet->delivery_charge_earned += $order['shipping_cost'];
                    $wallet->total_earning += ($order_amount - $commission) + $order_summary['total_tax'] + $order['shipping_cost'];
                } else {
                    $wallet->total_earning += ($order_amount - $commission) + $order_summary['total_tax'];
                }

                $wallet->total_tax_collected += $order_summary['total_tax'];
                $wallet->save();
            }
        }
    }

    public static function coupon_process($data, $coupon){
        $req = array_key_exists('request', $data) ? $data['request'] : null;
        $coupon_discount = 0;
        if(session()->has('coupon_discount')){
            $coupon_discount = session('coupon_discount');
        }elseif($req['coupon_discount']){
            $coupon_discount = $req['coupon_discount'];
        }

        $carts = $req ? CartManager::get_cart_for_api($req) : CartManager::get_cart();
     // dd($carts);
        $group_id_wise_cart = CartManager::get_carts($data['cart_group_id']);
      
        $total_amount = 0;

        foreach($carts as $cart) {
            $price = DB::table('sku_product_new')->where('id',$cart->variation)->first();
 //dd($cart->quantity,$price->listed_price);
            if (($coupon->seller_id == NULL && $cart->seller_is=='admin') || $coupon->seller_id == '0' || ($coupon->seller_id == $cart->seller_id && $cart->seller_is=='seller')) {
                $total_amount += ($price->listed_price * $cart->quantity);

            }
        }
      // dd($total_amount);
        if(($group_id_wise_cart[0]->seller_is=='admin' && $coupon->seller_id == NULL) || $coupon->seller_id == '0' || ($coupon->seller_id == $group_id_wise_cart[0]->seller_id && $group_id_wise_cart[0]->seller_is=='seller')){
            $cart_group_ids = CartManager::get_cart_group_ids($req ?? null);
            $discount = 0;
     
            if ($coupon->coupon_type == 'discount_on_purchase' || $coupon->coupon_type == 'first_order') {
                $group_id_percent = array();
                foreach ($cart_group_ids as $cart_group_id) {
                    $cart_group_data = $req ? CartManager::get_cart_for_api($req, $cart_group_id) : CartManager::get_carts($cart_group_id);
                  //dd($cart_group_data);
                    $cart_group_amount = 0;
                    if ($coupon->seller_id == NULL || $coupon->seller_id == '0' || $coupon->seller_id == $cart_group_data[0]->seller_id) {
                        
                        $cart_group_amount = $cart_group_data->sum(function ($item) {
                           
                            $price = DB::table('sku_product_new')->where('id',$item->variation)->first();
                           
                            return ($price->listed_price * $item->quantity);
                        });
                    }
                 
                    $percent = number_format(($cart_group_amount / $total_amount) * 100, 2);
                
                    $group_id_percent[$cart_group_id] = $percent;
                       
                }
                $discount = ($group_id_percent[$data['cart_group_id']] * $coupon_discount) / 100;

            } elseif ($coupon->coupon_type == 'free_delivery') {
                $shippingMethod=Helpers::get_business_settings('shipping_method');

                $free_shipping_by_group_id = array();
                foreach ($cart_group_ids as $cart_group_id) {
                    $cart_group_data = $req ? CartManager::get_cart_for_api($req, $cart_group_id) : CartManager::get_cart($cart_group_id);

                    if( $shippingMethod == 'inhouse_shipping') {
                        $admin_shipping = \App\Model\ShippingType::where('seller_id', 0)->first();
                        $shipping_type = isset($admin_shipping) == true ? $admin_shipping->shipping_type : 'order_wise';
                    }else {

                        if ($cart_group_data[0]->seller_is == 'admin') {
                            $admin_shipping = \App\Model\ShippingType::where('seller_id', 0)->first();
                            $shipping_type = isset($admin_shipping) == true ? $admin_shipping->shipping_type : 'order_wise';
                        } else {
                            $seller_shipping = \App\Model\ShippingType::where('seller_id', $cart_group_data[0]->seller_id)->first();
                            $shipping_type = isset($seller_shipping) == true ? $seller_shipping->shipping_type : 'order_wise';
                        }
                    }

                    if($shipping_type == 'order_wise' && (($coupon->seller_id == null && $cart_group_data[0]->seller_is == 'admin') || $coupon->seller_id == '0' || $coupon->seller_id == $cart_group_data[0]->seller_id)) {
                        $free_shipping_by_group_id[$cart_group_id] = $cart_group_data[0]->cart_shipping->shipping_cost ?? 0;
                    }else{
                        if(($coupon->seller_id == null && $cart_group_data[0]->seller_is == 'admin') || $coupon->seller_id == '0' || $coupon->seller_id == $cart_group_data[0]->seller_id) {
                            $shipping_cost = CartManager::get_shipping_cost($data['cart_group_id']);
                            $free_shipping_by_group_id[$cart_group_id] = $shipping_cost;
                        }
                    }
                }
                $discount = (isset($free_shipping_by_group_id[$data['cart_group_id']]) && $free_shipping_by_group_id[$data['cart_group_id']]) ? $free_shipping_by_group_id[$data['cart_group_id']] : 0;
            }
            $calculate_data = array(
                'discount' => $discount,
                'coupon_bearer' => $coupon->coupon_bearer,
                'coupon_code' => $coupon->code,
            );
            return $calculate_data;
        }

        $calculate_data = array(
            'discount' => 0,
            'coupon_bearer' => 'inhouse',
            'coupon_code' => 0,
        );

        return $calculate_data;
    }

    // public static function generate_order($data)
    // {
       
    //     $req = array_key_exists('request', $data) ? $data['request'] : null;
    //     $coupon_process = array(
    //         'discount' => 0,
    //         'coupon_bearer' => 'inhouse',
    //         'coupon_code' => 0,
    //     );
    //     if((isset($req['coupon_code']) && $req['coupon_code']) || session()->has('coupon_code')){
    //         $coupon_code = $req['coupon_code'] ?? session('coupon_code');
    //         $coupon = Coupon::where(['code' => $coupon_code])
    //             ->where('status',1)
    //             ->first();

    //         $coupon_process = $coupon ? self::coupon_process($data, $coupon) : $coupon_process;
    //     }
    //     $order_id = 1000000 + Order::all()->count() + 1;
    //     if (Order::find($order_id)) {
    //         $order_id = Order::orderBy('id', 'DESC')->first()->id + 1;
    //     }
    //     $address_id = session('address_id') ? session('address_id') : null;
    //     $billing_address_id = session('billing_address_id') ? session('billing_address_id') : null;
    //     $coupon_code = $coupon_process['coupon_code'];
    //     $coupon_bearer = $coupon_process['coupon_bearer'];
    //     $discount = $coupon_process['discount'];
    //     $order_note = session()->has('order_note') ? session('order_note') : null;
       
    //     $cart_group_id = $data['cart_group_id'];
    //     $admin_commission = (int) str_replace(",","",Helpers::sales_commission_before_order($cart_group_id, $discount));
    //     if ($req != null) {
    //         if (session()->has('address_id') == false) {
    //             $address_id = $req->has('address_id') ? $req['address_id'] : null;
    //         }
    //     }
    //     $user = Helpers::get_customer($req);
   
    //     $seller_data = DB::table('new_cart')->where(['cart_group_id' => $cart_group_id])->first();
    //    // dd($seller_data);
    //     $shipping_method = CartShipping::where(['cart_group_id' => $cart_group_id])->first();
    //     if (isset($shipping_method)) {
    //         $shipping_method_id = $shipping_method->shipping_method_id;
    //     } else {
    //         $shipping_method_id = 0;
    //     }
 
    //     $shipping_model = Helpers::get_business_settings('shipping_method');
    //     if ($shipping_model == 'inhouse_shipping') 
    //     {
    //         $admin_shipping = ShippingType::where('seller_id', 0)->first();
    //         $shipping_type = isset($admin_shipping) == true ? $admin_shipping->shipping_type : 'order_wise';
    //     } else {
    //         if ($seller_data->seller_is == 'admin') {
    //             $admin_shipping = ShippingType::where('seller_id', 0)->first();
    //             $shipping_type = isset($admin_shipping) == true ? $admin_shipping->shipping_type : 'order_wise';
    //         } else {
    //             $seller_shipping = ShippingType::where('seller_id', $seller_data->seller_id)->first();
    //             $shipping_type = isset($seller_shipping) == true ? $seller_shipping->shipping_type : 'order_wise';
    //         }
    //     }
      
    //     if($req['wallet_deduct_amount']> 0)
    //     {
    //          $user_data = User::where('id',$user->id)->first();
    //          if($user_data->wallet_balance > 0 ){
    //          $user_data->wallet_balance -= $req['wallet_deduct_amount'];
    //          $user_data->save();
    //          }
    //                 $wdata = new CustomerWalletHistory;
    //                 $wdata->customer_id = $user->id;
    //                 $wdata->transaction_type = 0;
    //                 $wdata->transaction_amount = $req['wallet_deduct_amount'];
    //                 $wdata->transaction_method = "Deduction";
    //                 $wdata->save();
    //     }
        
    //     $instant_delivery = 0;
    //     $product_instant_delivery_status = Product::where('id',$seller_data->product_id)->where('available_instant_delivery',1)->first();
    //     if($product_instant_delivery_status)
    //     {
    //         $shipping_address = ShippingAddress::where('customer_id',$seller_data->customer_id)->where('city',$seller_data->seller_city)->first();
    //         if($shipping_address)
    //         {
    //            $instant_delivery = 1; 
    //         }else{
    //            $instant_delivery = 0; 
    //         }
    //     }
        
    //     if($req['instant_delivery'])
    //     {
    //          $instant_delivery = 1; 
    //     }
        
    //     session()->forget('instant_delivery');
    //     $shipping_fee_details = CartManager::get_shipping_cost($data['cart_group_id']);
    //      if($req['shipping_fee'] == '0.00')
    //     {
    //         $shipping_fee = 0;
    //     }else
    //     {
    //          $shipping_fee = $req['shipping_fee']; 
    //     }
        
       
    //     $or = [
    //         'id' => $order_id,
    //         'verification_code' => rand(1000000, 9999999),
    //         'customer_id' => $user->id,
    //         'seller_id' => $seller_data->seller_id,
    //         'seller_is' => $seller_data->seller_is,
    //         'customer_type' => 'customer',
    //         'payment_status' => $data['payment_status'],
    //         'order_status' => $data['order_status'],
    //         'payment_method' => $data['payment_method'],
    //         'transaction_ref' => $data['transaction_ref'],
    //         'payment_by' => isset($data['payment_by']) ? $data['payment_by'] : NULL,
    //         'payment_note' => isset($data['payment_note']) ? $data['payment_note'] : NULL,
    //         'order_group_id' => $data['order_group_id'],
    //         'discount_amount' => $discount,
    //         'discount_type' => $discount == 0 ? null : 'coupon_discount',
    //         'coupon_code' => $coupon_code,
    //         'coupon_discount_bearer' => $coupon_bearer,
    //         'order_amount' => CartManager::cart_grand_total($cart_group_id) - $discount,
    //         'admin_commission' => $admin_commission,
    //         'shipping_address' => $address_id,
    //         'shipping_address_data' => ShippingAddress::find($address_id),
    //         'billing_address' => $billing_address_id,
    //         'billing_address_data' => ShippingAddress::find($billing_address_id),
    //         'shipping_cost' => $shipping_fee, 
    //         'shipping_cost_amt' => $shipping_fee_details, 
    //         'shipping_method_id' => $shipping_method_id,
    //         'shipping_type' => $shipping_type,
    //         'cashback_amount' => null,
    //         'wallet_deduction' => isset($req['wallet_deduct_amount']) ? $req['wallet_deduct_amount'] : 0,
    //         'instant_delivery_type' =>  $instant_delivery,
    //         'gst_number' => isset($req['gstNumber']) ? $req['gstNumber'] : NULL,
    //         'company_name' => isset($req['gstCompanyName']) ? $req['gstCompanyName'] : NULL,
    //         'created_at' => now(),
    //         'updated_at' => now(),
    //         'order_note' => $order_note
    //     ];
        
      

    //     //        confirmed
    //     DB::table('orders')->insertGetId($or);

    //     //  dd($order_id);
    //     self::add_order_status_history($order_id, auth('customer')->id(), $data['payment_status']=='paid'?'confirmed':'pending', 'customer');
    //    //dd('hello');
    //     foreach (CartManager::get_carts($data['cart_group_id']) as $c) {
            
    //         $product = Product::where(['id' => $c->product_id])->first();
    //         $sku_pro = DB::table('sku_product_new')->where('product_id',$c->product_id)->where('id',$c->variation)->first();
    //         $variation = json_encode([
    //                  "color"=>$c->colors,
    //                  "size"=> $sku_pro->sizes
    //         ]);

    //         $or_d = [
    //             'order_id' => $order_id,
    //             'product_id' => $c->product_id,
    //             'order_status_details'=>$data['order_status'],
    //             'seller_id' => $c->seller_id,
    //             'product_details' => $product,
    //             'qty' => $c->quantity,
    //             'price' => $sku_pro->variant_mrp,
    //             'tax' => $sku_pro->tax,
    //             'tax_model' => 'exclude',
    //             'discount' => $sku_pro->discount,
    //             'discount_type' => $sku_pro->discount_type,
    //             'variant' => $sku_pro->variation,
    //             'variation' => $variation,
    //             'delivery_status' => 'pending',
    //             'shipping_method_id' => null,
    //             'payment_status' => 'unpaid',
    //             'created_at' => now(),
    //             'updated_at' => now()
    //         ];
          
             
    //          DB::table('sku_product_new')->where('id',$c->variation)->update([
    //                     'quantity'=>$sku_pro->quantity - $c->quantity
    //           ]);
    //         DB::table('order_details')->insert($or_d);
          
    //     }

    //     if ($or['payment_method'] != 'cash_on_delivery' && $or['payment_method'] != 'offline_payment') {
    //         $order = Order::find($order_id);
    //         $order_summary = OrderManager::order_summary($order);
    //         $order_amount = $order_summary['subtotal'] - $order_summary['total_discount_on_product'] - $order['discount'];

    //         DB::table('order_transactions')->insert([
    //             'transaction_id' => OrderManager::gen_unique_id(),
    //             'customer_id' => $order['customer_id'],
    //             'seller_id' => $order['seller_id'],
    //             'seller_is' => $order['seller_is'],
    //             'order_id' => $order_id,
    //             'order_amount' => $order_amount,
    //             'seller_amount' => $order_amount - $admin_commission,
    //             'admin_commission' => $admin_commission,
    //             'received_by' => 'admin',
    //             'status' => 'hold',
    //             'delivery_charge' => $order['shipping_cost'],
    //             'tax' => $order_summary['total_tax'],
    //             'delivered_by' => 'admin',
    //             'payment_method' => $or['payment_method'],
    //             'created_at' => now(),
    //             'updated_at' => now(),
    //         ]);

    //         if (AdminWallet::where('admin_id', 1)->first() == false) {
    //             DB::table('admin_wallets')->insert([
    //                 'admin_id' => 1,
    //                 'withdrawn' => 0,
    //                 'commission_earned' => 0,
    //                 'inhouse_earning' => 0,
    //                 'delivery_charge_earned' => 0,
    //                 'pending_amount' => 0,
    //                 'created_at' => now(),
    //                 'updated_at' => now(),
    //             ]);
    //         }
    //         DB::table('admin_wallets')->where('admin_id', $order['seller_id'])->increment('pending_amount', $order['order_amount']);
    //     }

    //     if ($seller_data->seller_is == 'admin') {
    //         $seller = Admin::find($seller_data->seller_id);
    //     } else {
    //         $seller = Seller::find($seller_data->seller_id);
    //     }

    //     try {
    //         $fcm_token = $user->cm_firebase_token;
    //         $seller_fcm_token = $seller->cm_firebase_token;
    //         if ($data['payment_method'] != 'cash_on_delivery' && $or['payment_method'] != 'offline_payment') {
    //             $value = Helpers::order_status_update_message('confirmed');
    //         } else {
    //             $value = Helpers::order_status_update_message('pending');
    //         }

    //         if ($value) {
    //             $data = [
    //                 'title' => translate('order'),
    //                 'description' => $value,
    //                 'order_id' => $order_id,
    //                 'image' => '',
    //             ];
    //             Helpers::send_push_notif_to_device($fcm_token, $data);
    //             Helpers::send_push_notif_to_device($seller_fcm_token, $data);
    //         }

    //         $emailServices_smtp = Helpers::get_business_settings('mail_config');
    //         if ($emailServices_smtp['status'] == 0) {
    //             $emailServices_smtp = Helpers::get_business_settings('mail_config_sendgrid');
    //         }
    //         if ($emailServices_smtp['status'] == 1) {
    //             Mail::to($user->email)->send(new \App\Mail\OrderPlaced($order_id));
    //             Mail::to($seller->email)->send(new \App\Mail\OrderReceivedNotifySeller($order_id));
    //         }
    //     } catch (\Exception $exception) {
    //         //echo $exception;
    //     }

    //     return $order_id;
    // }

    public static function generate_order($data)
    {
    $req = $data['request'] ?? null;
      //dd($req->amount);
    // Handle coupon
    $coupon_process = [
        'discount' => 0,
        'coupon_bearer' => 'inhouse',
        'coupon_code' => 0,
    ];

    $coupon_code = $req['coupon_code'] ?? session('coupon_code');
    if ($coupon_code) {
        $coupon = Coupon::where('code', $coupon_code)->where('status', 1)->first();
        $coupon_process = $coupon ? self::coupon_process($data, $coupon) : $coupon_process;
       // dd($coupon_process);
    }

    // Determine unique order ID
    $order_id = 1000000 + Order::count() + 1;
    if (Order::find($order_id)) {
        $order_id = Order::orderByDesc('id')->first()->id + 1;
    }

    // Prepare variables
    $address_id = session('address_id') ?? $req['address_id'] ?? null;
    $billing_address_id = session('billing_address_id');
    $order_note = session('order_note');

    $discount = $coupon_process['discount'];
    $coupon_code = $coupon_process['coupon_code'];
    $coupon_bearer = $coupon_process['coupon_bearer'];

    $cart_group_id = $data['cart_group_id'];
    $admin_commission = (int) str_replace(",", "", Helpers::sales_commission_before_order($cart_group_id, $discount));
    $user = Helpers::get_customer($req);
    $seller_data = DB::table('new_cart')->where('cart_group_id', $cart_group_id)->first();
    $shipping_method_id = CartShipping::where('cart_group_id', $cart_group_id)->value('shipping_method_id') ?? 0;
    $shipping_fees = CartShipping::where('cart_group_id', $cart_group_id)->value('shipping_cost') ?? 0;
   // dd($shipping_fees);
    // Determine shipping type
    $shipping_model = Helpers::get_business_settings('shipping_method');
    $shipping_type = 'order_wise';
    if ($shipping_model === 'inhouse_shipping' || $seller_data->seller_is === 'admin') {
        $shipping_type = ShippingType::where('seller_id', 0)->value('shipping_type') ?? 'order_wise';
    } else {
        $shipping_type = ShippingType::where('seller_id', $seller_data->seller_id)->value('shipping_type') ?? 'order_wise';
    }

    // Wallet deduction
    $wallet_deduct_amount = $req['wallet_deduct_amount'] ?? 0;
    if($wallet_deduct_amount> 0)
    {
         $user_data = User::where('id',$user->id)->first();
         if($user_data->wallet_balance > 0 ){
         $user_data->wallet_balance -= $req['wallet_deduct_amount'];
         $user_data->save();
         }
                $wdata = new CustomerWalletHistory;
                $wdata->customer_id = $user->id;
                $wdata->transaction_type = 0;
                $wdata->transaction_amount = $req['wallet_deduct_amount'];
                $wdata->transaction_method = "Deduction";
                $wdata->save();
    }

    // Instant Delivery Check
    $instant_delivery = 0;
    if (Product::where('id', $seller_data->product_id)->where('available_instant_delivery', 1)->exists()) {
        if (ShippingAddress::where([
            'customer_id' => $seller_data->customer_id,
            'city' => $seller_data->seller_city
        ])->exists()) {
            $instant_delivery = 1;
        }
    }

    if (!empty($req['instant_delivery'])) {
        $instant_delivery = 1;
    }

    session()->forget('instant_delivery');

    // Shipping Fee
    $shipping_fee_details = CartManager::get_shipping_cost($cart_group_id);
    $shipping_fee = ($req['shipping_fee'] ?? 0) == '0.00' ? 0 : $req['shipping_fee'];

    // Prepare order array
    $order_data = [
        'id' => $order_id,
        'verification_code' => rand(1000000, 9999999),
        'customer_id' => $user->id,
        'seller_id' => $seller_data->seller_id,
        'seller_is' => $seller_data->seller_is,
        'customer_type' => 'customer',
        'payment_status' => $data['payment_status'],
        'order_status' => $data['order_status'],
        'payment_method' => $data['payment_method'],
        'transaction_ref' => $data['transaction_ref'],
        'payment_by' => $data['payment_by'] ?? null,
        'payment_note' => $data['payment_note'] ?? null,
        'order_group_id' => $data['order_group_id'],
        'discount_amount' => $discount,
        'discount_type' => $discount ? 'coupon_discount' : null,
        'coupon_code' => $coupon_code,
        'coupon_discount_bearer' => $coupon_bearer,
        'order_amount' => CartManager::cart_grand_total($cart_group_id) - $discount,
        'admin_commission' => $admin_commission,
        'shipping_address' => $address_id,
        'shipping_address_data' => ShippingAddress::find($address_id),
        'billing_address' => $billing_address_id,
        'billing_address_data' => ShippingAddress::find($billing_address_id),
        'shipping_cost' => $shipping_fees,
        'amount'=>$req->amount,
        'shipping_cost_amt' => $shipping_fee_details,
        'shipping_method_id' => $shipping_method_id,
        'shipping_type' => $shipping_type,
        'cashback_amount' => null,
        'wallet_deduction' => $wallet_deduct_amount,
        'instant_delivery_type' => $instant_delivery,
        'gst_number' => $req['gstNumber'] ?? null,
        'company_name' => $req['gstCompanyName'] ?? null,
        'created_at' => now(),
        'updated_at' => now(),
        'order_note' => $order_note
    ];

    DB::table('orders')->insert($order_data);
    self::add_order_status_history($order_id, auth('customer')->id(), $data['payment_status'] == 'paid' ? 'confirmed' : 'pending', 'customer');

    // Order details
    foreach (CartManager::get_carts($cart_group_id) as $c) {
        $product = Product::find($c->product_id);
        $sku = DB::table('sku_product_new')->where('product_id', $c->product_id)->where('id', $c->variation)->first();

        $variation = json_encode([
            "color" => $c->colors,
            "size" => $sku->sizes
        ]);

        DB::table('order_details')->insert([
            'order_id' => $order_id,
            'product_id' => $c->product_id,
            'order_status_details' => $data['order_status'],
            'seller_id' => $c->seller_id,
            'product_details' => $product,
            'qty' => $c->quantity,
            'price' => $sku->variant_mrp,
            'tax' => $sku->tax,
            'tax_model' => 'exclude',
            'discount' => $sku->discount,
            'discount_type' => $sku->discount_type,
            'variant' => $sku->variation,
            'variation' => $variation,
            'delivery_status' => 'pending',
            'shipping_method_id' => null,
            'payment_status' => 'unpaid',
            'created_at' => now(),
            'updated_at' => now()
        ]);

        DB::table('sku_product_new')->where('id', $c->variation)->where('quantity','>',0)->decrement('quantity', $c->quantity);
    }
                   
    // Handle non-COD transactions
    if (!in_array($order_data['payment_method'], ['cash_on_delivery', 'offline_payment'])) {
        $order = Order::find($order_id);
        $summary = OrderManager::order_summary($order);
        $amount = $summary['subtotal'] - $summary['total_discount_on_product'] - $order->discount;

        DB::table('order_transactions')->insert([
            'transaction_id' => OrderManager::gen_unique_id(),
            'customer_id' => $order->customer_id,
            'seller_id' => $order->seller_id,
            'seller_is' => $order->seller_is,
            'order_id' => $order_id,
            'order_amount' => $amount,
            'seller_amount' => $amount - $admin_commission,
            'admin_commission' => $admin_commission,
            'received_by' => 'admin',
            'status' => 'hold',
            'delivery_charge' => $order->shipping_cost,
            'tax' => $summary['total_tax'],
            'delivered_by' => 'admin',
            'payment_method' => $order_data['payment_method'],
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        AdminWallet::firstOrCreate(['admin_id' => 1], [
            'withdrawn' => 0,
            'commission_earned' => 0,
            'inhouse_earning' => 0,
            'delivery_charge_earned' => 0,
            'pending_amount' => 0,
        ]);

                    $previousBalance = WalletTransaction::where('user_id', $order->customer_id)
    ->orderBy('id', 'desc')
    ->value('balance') ?? 0;

$wallet_transaction = new WalletTransaction;
$wallet_transaction->user_id = $order->customer_id;
$wallet_transaction->transaction_id = self::gen_unique_id();
$wallet_transaction->debit  = $wallet_deduct_amount;
$wallet_transaction->balance = $previousBalance - $wallet_deduct_amount; // ✅ correct calculation
$wallet_transaction->transaction_type = "deduction";
$wallet_transaction->reference = 'Order #' . $order->id;
$wallet_transaction->save();

// Update user wallet
$user = User::find($order->customer_id);
if ($user) {
    $user->wallet_balance = $user->wallet_balance - $wallet_deduct_amount; // ✅
    $user->save();
}


        DB::table('admin_wallets')->where('admin_id', $order->seller_id)->increment('pending_amount', $order->order_amount);
    }

    // Notifications
    $seller = $seller_data->seller_is === 'admin' ? Admin::find($seller_data->seller_id) : Seller::find($seller_data->seller_id);

    try {
        $fcm_token = $user->cm_firebase_token;
        $seller_fcm_token = $seller->cm_firebase_token;

        $message = Helpers::order_status_update_message($order_data['payment_method'] != 'cash_on_delivery' ? 'confirmed' : 'pending');
        if ($message) {
            $notif = [
                'title' => translate('order'),
                'description' => $message,
                'order_id' => $order_id,
                'image' => '',
            ];
            Helpers::send_push_notif_to_device($fcm_token, $notif);
            Helpers::send_push_notif_to_device($seller_fcm_token, $notif);
        }

        $mail_config = Helpers::get_business_settings('mail_config');
        if ($mail_config['status'] == 0) {
            $mail_config = Helpers::get_business_settings('mail_config_sendgrid');
        }

        if ($mail_config['status'] == 1) {
            Mail::to($user->email)->send(new \App\Mail\OrderPlaced($order_id));
            Mail::to($seller->email)->send(new \App\Mail\OrderReceivedNotifySeller($order_id));
        }
    } catch (\Exception $ex) {
        // Log error silently
    }

    return $order_id;
    }

    
    public static function generate_orders($data)
    {
    $req = array_key_exists('request', $data) ? $data['request'] : null;

    // Generate a new unique order ID
    $order_id = Order::orderBy('id', 'DESC')->first()->id + 1;

    // Get cart group ID and user
    $cart_group_id = $data['cart_group_id'];
    $user = Helpers::get_customer($req);

    // Get seller data from cart
    $seller_data = DB::table('new_cart')->where(['cart_group_id' => $cart_group_id])->first();

    // Create order data array
    $or = [
        'id' => $order_id,
        'verification_code' => rand(1000000, 9999999),
        'customer_id' => $user->id,
        'seller_id' => $seller_data->seller_id,
        'seller_is' => $seller_data->seller_is,
        'customer_type' => 'customer',
        'payment_status' => $data['payment_status'],
        'order_status' => $data['order_status'],
        'payment_method' => $data['payment_method'],
        'transaction_ref' => $data['transaction_ref'],
        'payment_by' => $data['payment_by'] ?? NULL,
        'payment_note' => $data['payment_note'] ?? NULL,
        'order_group_id' => $data['order_group_id'],
        'discount_amount' => 0,
        'discount_type' => 'coupon_discount',
        'coupon_code' => null,
        'coupon_discount_bearer' => 0,
        'order_amount' => 200,
        'admin_commission' => 0,
        'shipping_address' => null,
        'shipping_address_data' => null,
        'billing_address' => 'varansi',
        'billing_address_data' => null,
        'shipping_cost' => 0,
        'shipping_cost_amt' => 0,
        'shipping_method_id' => 0,
        'shipping_type' => 0,
        'cashback_amount' => 0,
        'wallet_deduction' => 0,
        'instant_delivery_type' => 1,
        'gst_number' => NULL,
        'company_name' => NULL,
        'created_at' => now(),
        'updated_at' => now(),
        'order_note' => null
    ];

    // Insert order in DB
    DB::table('orders')->insertGetId($or);

    // Add order status history
    self::add_order_status_history($order_id, auth('customer')->id(), $data['payment_status'] == 'paid' ? 'confirmed' : 'pending', 'customer');

    // Fetch cart items and insert order details
    foreach (CartManager::get_carts($cart_group_id) as $c) {
        $product = Product::where(['id' => $c->product_id])->first();
        $sku_pro = DB::table('sku_product_new')->where('product_id', $c->product_id)->where('id', $c->variation)->first();

        $variation = json_encode([
            "color" => $c->colors,
            "size" => $sku_pro->sizes
        ]);

        $or_d = [
            'order_id' => $order_id,
            'product_id' => $c->product_id,
            'seller_id' => $c->seller_id,
            'product_details' => $product,
            'qty' => $c->quantity,
            'price' => $sku_pro->variant_mrp,
            'tax' => $sku_pro->tax,
            'tax_model' => 'exclude',
            'discount' => $sku_pro->discount,
            'discount_type' => $sku_pro->discount_type,
            'variant' => $sku_pro->variation,
            'variation' => $variation,
            'delivery_status' => 'pending',
            'shipping_method_id' => null,
            'payment_status' => 'unpaid',
            'created_at' => now(),
            'updated_at' => now()
        ];

        DB::table('order_details')->insert($or_d);
    }

    return $order_id;
    }


}
